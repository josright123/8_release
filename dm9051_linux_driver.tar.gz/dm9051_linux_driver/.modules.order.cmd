savedcmd_/home/pi/Public/prg/ptp/dm9051_linux_driver/modules.order := {   echo /home/pi/Public/prg/ptp/dm9051_linux_driver/dm9051.o; :; } > /home/pi/Public/prg/ptp/dm9051_linux_driver/modules.order
