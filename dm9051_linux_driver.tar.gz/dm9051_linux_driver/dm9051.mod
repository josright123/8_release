/home/pi/Public/prg/ptp/dm9051_linux_driver/dm9051_main.o
/home/pi/Public/prg/ptp/dm9051_linux_driver/dm9051_ptp.o
