#include <linux/module.h>
#include <linux/export-internal.h>
#include <linux/compiler.h>

MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

KSYMTAB_FUNC(dm9051_set_reg, "", "");
KSYMTAB_FUNC(dm9051_get_reg, "", "");
KSYMTAB_FUNC(dm9051_set_regs, "", "");
KSYMTAB_FUNC(dm9051_get_regs, "", "");
KSYMTAB_FUNC(dm9051_write_mem, "", "");
KSYMTAB_FUNC(dm9051_read_mem, "", "");

SYMBOL_CRC(dm9051_set_reg, 0xb078ed87, "");
SYMBOL_CRC(dm9051_get_reg, 0xedbd624b, "");
SYMBOL_CRC(dm9051_set_regs, 0xcd1319f4, "");
SYMBOL_CRC(dm9051_get_regs, 0x746ef052, "");
SYMBOL_CRC(dm9051_write_mem, 0xdcc54507, "");
SYMBOL_CRC(dm9051_read_mem, 0x1f7c4183, "");

static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0xc1514a3b, "free_irq" },
	{ 0xd223f583, "regmap_write" },
	{ 0x4508ef20, "skb_put" },
	{ 0x95c62d45, "skb_tstamp_tx" },
	{ 0x3462fe9b, "consume_skb" },
	{ 0x656e4a6e, "snprintf" },
	{ 0xc5b6f236, "queue_work_on" },
	{ 0x35d48200, "skb_dequeue" },
	{ 0xc2f13722, "phy_connect" },
	{ 0x46708e44, "ptp_clock_index" },
	{ 0x4829a47e, "memcpy" },
	{ 0x64898fd0, "spi_write_then_read" },
	{ 0x48a49f08, "phy_ethtool_set_link_ksettings" },
	{ 0xfbc06195, "eth_validate_addr" },
	{ 0xc3055d20, "usleep_range_state" },
	{ 0xafaf3a65, "eth_commit_mac_addr_change" },
	{ 0xc5ba021, "netdev_err" },
	{ 0x9fe5b3cb, "skb_queue_purge_reason" },
	{ 0x1ee033ff, "dev_addr_mod" },
	{ 0x2a86a5c0, "ptp_find_pin" },
	{ 0x4b85eef5, "eth_type_trans" },
	{ 0xcc73bcfb, "ptp_parse_header" },
	{ 0x52822041, "phy_support_sym_pause" },
	{ 0x122c3a7e, "_printk" },
	{ 0xf0fdf6cb, "__stack_chk_fail" },
	{ 0xb2fcb56d, "queue_delayed_work_on" },
	{ 0x6cbbfc54, "__arch_copy_to_user" },
	{ 0xc4b7b41e, "eth_prepare_mac_addr_change" },
	{ 0x1a283f39, "_dev_info" },
	{ 0x41142d4d, "skb_queue_tail" },
	{ 0x3bb48fd9, "phy_ethtool_get_link_ksettings" },
	{ 0x476b165a, "sized_strscpy" },
	{ 0xea447125, "ptp_classify_raw" },
	{ 0x820ffb2c, "devm_alloc_etherdev_mqs" },
	{ 0x9c771906, "spi_sync" },
	{ 0xf810f451, "_dev_err" },
	{ 0x78c56f26, "ptp_clock_register" },
	{ 0x1b8267b5, "irq_get_irq_data" },
	{ 0x69dd3b5b, "crc32_le" },
	{ 0x4dfa8d4b, "mutex_lock" },
	{ 0x9166fada, "strncpy" },
	{ 0xd51bf3d7, "driver_unregister" },
	{ 0x9ec6ca96, "ktime_get_real_ts64" },
	{ 0x96df59ad, "ethtool_op_get_link" },
	{ 0xcefb0c9f, "__mutex_init" },
	{ 0xdfc74945, "netif_tx_wake_queue" },
	{ 0x610cb600, "phy_start" },
	{ 0x65929cae, "ns_to_timespec64" },
	{ 0xdcb764ad, "memset" },
	{ 0xb5e989ce, "ptp_clock_event" },
	{ 0x90ea3e35, "phy_print_status" },
	{ 0x87bb7e6e, "ptp_clock_unregister" },
	{ 0x755eed83, "phy_start_aneg" },
	{ 0x95be6f5b, "netif_rx" },
	{ 0xfece216c, "__netdev_alloc_skb" },
	{ 0x87cb7758, "regmap_noinc_read" },
	{ 0xcb93779e, "devm_mdiobus_alloc_size" },
	{ 0x15ba50a6, "jiffies" },
	{ 0x3c3ff9fd, "sprintf" },
	{ 0xd35d832, "devm_register_netdev" },
	{ 0xd9fa358f, "regmap_read" },
	{ 0xcd760096, "regmap_bulk_write" },
	{ 0x3800981d, "regmap_noinc_write" },
	{ 0x3213f038, "mutex_unlock" },
	{ 0x9fa7184a, "cancel_delayed_work_sync" },
	{ 0xc6f46339, "init_timer_key" },
	{ 0xafbeba1c, "__spi_register_driver" },
	{ 0xb43f9365, "ktime_get" },
	{ 0x3c12dfe, "cancel_work_sync" },
	{ 0xdccfefc3, "regmap_bulk_read" },
	{ 0xffeedf6a, "delayed_work_timer_fn" },
	{ 0x12a4e128, "__arch_copy_from_user" },
	{ 0x61d2e72e, "phy_ethtool_nway_reset" },
	{ 0xc32874e4, "ktime_get_snapshot" },
	{ 0xa65c6def, "alt_cb_patch_nops" },
	{ 0x70c16e79, "__devm_mdiobus_register" },
	{ 0x41ed3709, "get_random_bytes" },
	{ 0x6600349a, "regmap_update_bits_base" },
	{ 0xca311bb8, "dev_err_probe" },
	{ 0xb5fa03e, "phy_stop" },
	{ 0x2e6ebf32, "phy_set_sym_pause" },
	{ 0x9355a068, "skb_clone_tx_timestamp" },
	{ 0x68bc950b, "phy_disconnect" },
	{ 0xf9a482f9, "msleep" },
	{ 0x2d3385d3, "system_wq" },
	{ 0x2f2c95c4, "flush_work" },
	{ 0x7eeb7d99, "__devm_regmap_init" },
	{ 0x39ff040a, "module_layout" },
};

MODULE_INFO(depends, "");


MODULE_INFO(srcversion, "707E742DC62767C257BFB32");
