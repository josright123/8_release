/*
 * drivers/net/ethernet/davicom/dm9051_ptp.c
 * Copyright 2021 Davicom Semiconductor,Inc.
 *
 * 	This program is free software; you can redistribute it and/or
 * 	modify it under the terms of the GNU General Public License
 * 	as published by the Free Software Foundation; either version 2
 * 	of the License, or (at your option) any later version.
 *
 * 	This program is distributed in the hope that it will be useful,
 * 	but WITHOUT ANY WARRANTY; without even the implied warranty of
 * 	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * 	GNU General Public License for more details.
 *
 *	http://www.davicom.com.tw/
 *	Stone SHYR <stone_shyr@davicom.com.tw>
 */

#include <linux/crc32.h>
//#include <linux/kernel.h>
#include <linux/if_vlan.h>
#include <linux/list.h>
#include <linux/module.h>
#include <linux/net_tstamp.h>
#include <linux/ptp_classify.h>
#include <linux/ptp_clock_kernel.h>
#include <linux/math64.h>
#include <linux/spi/spi.h>
#include <linux/regmap.h>
#include <linux/math64.h>
#include <linux/time64.h>
#include "dm9051.h"
#include "dm9051_ptp.h"
//#include "board_info.h"
static int ptp_9051_gettime(struct ptp_clock_info *ptp,
			    struct timespec64 *ts);

static int ptp_9051_settime(struct ptp_clock_info *ptp,
			    const struct timespec64 *ts);

static int ptp_9051_read_ts(struct board_info* db, u8* timestamp);

// debug print time stamp messages

#define MAX_RXTS	64
/* phyter seems to miss the mark by 16 ns */
#define ADJTIME_FIX	16
//#define SKB_TIMESTAMP_TIMEOUT	2 /* jiffies */
//#define SKB_TIMESTAMP_TIMEOUT	1 /* jiffies */
#define SKB_TIMESTAMP_TIMEOUT	0 /* jiffies */

#define N_EXT_TS	6
#define N_PER_OUT	7
#define PSF_PTPVER	2
#define PSF_EVNT	0x4000
#define PSF_RX		0x2000
#define PSF_TX		0x1000
#define EXT_EVENT	1
#define CAL_EVENT	7
#define CAL_TRIGGER	1
/*
 * Bits of the ptp_extts_request.flags field:
 */
#define PTP_ENABLE_FEATURE (1<<0)
#define PTP_RISING_EDGE    (1<<1)
#define PTP_FALLING_EDGE   (1<<2)
#define PTP_STRICT_FLAGS   (1<<3)
#define PTP_EXTTS_EDGES    (PTP_RISING_EDGE | PTP_FALLING_EDGE)
#define PTP_EXTTS_V1_VALID_FLAGS	(PTP_ENABLE_FEATURE |	\
					 PTP_RISING_EDGE |	\
					 PTP_FALLING_EDGE)

/* a list of clocks and a mutex to protect it */
static LIST_HEAD(phyter_clocks);
static DEFINE_MUTEX(phyter_clocks_lock);

/* flags controlling PTP/1588 function */
#define IGB_PTP_ENABLED		BIT(0)
#define IGB_PTP_OVERFLOW_CHECK	BIT(1)

//Stone add for GP1 trigger setup !
int trigger_ff = 0x01;
int trigger_70 = 0x01;
int tx_1588 = 0x00;


#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 7, 0)

int dm9051_get_ts_info(struct net_device *net_dev,
                       struct kernel_ethtool_ts_info *info)
#else

int dm9051_get_ts_info(struct net_device *net_dev,
                       struct ethtool_ts_info *info)
#endif // LINUX_VERSION_CODE >= KERNEL_VERSION(6, 7, 0)

{
	struct board_info *db = netdev_priv(net_dev);
	dm_printk("[in %s] *dm9051_ts_info*\n", __FUNCTION__);
        info->so_timestamping = (SOF_TIMESTAMPING_RX_SOFTWARE |
				 SOF_TIMESTAMPING_TX_SOFTWARE |
				 SOF_TIMESTAMPING_SOFTWARE);

	info->phc_index = db->ptp_clock ? ptp_clock_index(db->ptp_clock) : -1;
	info->so_timestamping =
		SOF_TIMESTAMPING_TX_SOFTWARE |
		SOF_TIMESTAMPING_RX_SOFTWARE |
		SOF_TIMESTAMPING_SOFTWARE |
		SOF_TIMESTAMPING_TX_HARDWARE |
		SOF_TIMESTAMPING_RX_HARDWARE |
		SOF_TIMESTAMPING_RAW_HARDWARE;

	info->tx_types =
		BIT(HWTSTAMP_TX_ONESTEP_SYNC) |
		BIT(HWTSTAMP_TX_OFF) |
		BIT(HWTSTAMP_TX_ON);

	info->rx_filters =
		BIT(HWTSTAMP_FILTER_NONE) |
		BIT(HWTSTAMP_FILTER_ALL);

	dm_printk("[%s] tx_types %x, rx_filters %x", __func__, info->tx_types, info->rx_filters);

	return 0;
}


static int write_rate_reg(struct board_info *db, u64 rate, int neg_adj)
{

	u8 s_ppm[4];
	u16 hi, lo;

	// clamp rate
	if (rate > 0xFFFFFFFF) {
		rate = 0xFFFFFFFF;
	}

	hi = (rate >> 16);
	lo = rate & 0xffff;

        s_ppm[0] = lo & 0xff;
	s_ppm[1] = (lo >> 8) & 0xff;
	s_ppm[2] = hi & 0xFF;
	s_ppm[3] = (hi >> 8) & 0xff;

	mutex_lock(&db->tsreg_lock);
	dm9051_set_reg(db, DM9051_1588_CLK_CTRL, DM9051_CCR_IDX_RST); //R61 W80
	dm9051_set_reg(db, DM9051_1588_TS, s_ppm[0]);  //Write register 0x68
	dm9051_set_reg(db, DM9051_1588_TS, s_ppm[1]);    //Write register 0x68
	dm9051_set_reg(db, DM9051_1588_TS, s_ppm[2]);  //Write register 0x68
	dm9051_set_reg(db, DM9051_1588_TS, s_ppm[3]);    //Write register 0x68

        if (neg_adj) {
		dm9051_set_reg(db, DM9051_1588_CLK_CTRL, DM9051_CCR_RATE_CTL | DM9051_CCR_PTP_RATE);
	} else {
		dm9051_set_reg(db, DM9051_1588_CLK_CTRL, DM9051_CCR_PTP_RATE);
	}
	mutex_unlock(&db->tsreg_lock);
        return 0;
}


static int ptp_9051_adjfine(struct ptp_clock_info *ptp, long scaled_ppm)
{
	// 171.798 = 2^32/25M (when rate reg use this value, every sec will increment 1 ns)
	const s32 RATE_BASE = 172;
 	struct board_info *db = container_of(ptp, struct board_info,
					     ptp_caps);
#ifdef DE_TIMESTAMP
	printk("+++00112+++++ [in %s] scaled_ppm = %ld, db.last_rate = %lld+++++++++\n",
	       __FUNCTION__ ,scaled_ppm, db->last_rate);
#endif

	// per RATE_BASE makes 1 ns increment per 25MHz
	s64 signed_rate = scaled_ppm_to_ppb(scaled_ppm) * RATE_BASE;
	s64 diff_rate = signed_rate - db->last_rate;
	int diff_rate_sign = 0;
	db->last_rate = signed_rate;
	if (diff_rate < 0) {
		diff_rate = -diff_rate;
		diff_rate_sign = 1;
	}

	write_rate_reg(db, diff_rate, diff_rate_sign);
	return 0;
}



static int ptp_9051_adjtime(struct ptp_clock_info *ptp, s64 delta)
{

	struct timespec64 diff = ns_to_timespec64(delta);
	struct board_info *db = container_of(ptp, struct board_info,
					     ptp_caps);
	mutex_lock(&db->tsreg_lock);
	dm9051_set_reg(db, DM9051_1588_CLK_CTRL, DM9051_CCR_IDX_RST);
	dm9051_set_reg(db, DM9051_1588_TS, (uint8_t)(diff.tv_nsec & 0xff));             // Write register 0x68
	dm9051_set_reg(db, DM9051_1588_TS, (uint8_t)((diff.tv_nsec >> 8) & 0xff));      // Write register 0x68
	dm9051_set_reg(db, DM9051_1588_TS, (uint8_t)((diff.tv_nsec >> 16) & 0xff));     // Write register 0x68
	dm9051_set_reg(db, DM9051_1588_TS, (uint8_t)((diff.tv_nsec >> 24) & 0xff));     // Write register 0x68

        dm9051_set_reg(db, DM9051_1588_TS, (uint8_t)(diff.tv_sec & 0xff));             // Write register 0x68
	dm9051_set_reg(db, DM9051_1588_TS, (uint8_t)((diff.tv_sec >> 8) & 0xff));      // Write register 0x68
	dm9051_set_reg(db, DM9051_1588_TS, (uint8_t)((diff.tv_sec >> 16) & 0xff));     // Write register 0x68
	dm9051_set_reg(db, DM9051_1588_TS, (uint8_t)((diff.tv_sec >> 24) & 0xff));     // Write register 0x68
	dm9051_set_reg(db, DM9051_1588_CLK_CTRL, DM9051_CCR_PTP_ADD);
	mutex_unlock(&db->tsreg_lock);
	dm_printk("[%s()], sec %lld, ns %ld", __func__, diff.tv_sec, diff.tv_nsec);
	return 0;
}

static int ptp_9051_read_ts(struct board_info* db, u8* timestamp)
{
	mutex_lock(&db->tsreg_lock);
	dm9051_set_reg(db, DM9051_1588_CLK_CTRL,
		       DM9051_CCR_IDX_RST | DM9051_CCR_PTP_READ);

        // bug fix: dm9051a 無法接受連續讀取
	// ret = dm9051_read_mem(db, DM9051_1588_TS, cur_ts, DM9051_1588_TS_BULK_SIZE);

	for (int i=0; i<8; i++) {
		dm9051_get_reg8(db, DM9051_1588_TS, timestamp + i);
	}

        mutex_unlock(&db->tsreg_lock);
	return 0;
}


static int ptp_9051_gettime(struct ptp_clock_info *ptp,
			    struct timespec64 *ts)
{
	struct board_info *db = container_of(ptp, struct board_info,
					     ptp_caps);
	u8 cur_ts[8];

        ptp_9051_read_ts(db, cur_ts);

	ts->tv_nsec = ((uint32_t)cur_ts[3] << 24) | ((uint32_t)cur_ts[2] << 16) |
		((uint32_t)cur_ts[1] << 8) | (uint32_t)cur_ts[0];
	ts->tv_sec = ((uint32_t)cur_ts[7] << 24) | ((uint32_t)cur_ts[6] << 16) |
		((uint32_t)cur_ts[5] << 8) | (uint32_t)cur_ts[4];

#ifdef DE_TIMESTAMP
	dm_printk("[%s] sec=%llx nsec=%lx", __func__, ts->tv_sec, ts->tv_nsec);
#endif
	return 0;
}


static int ptp_9051_settime(struct ptp_clock_info *ptp,
			    const struct timespec64 *ts)
{
	struct board_info *db = container_of(ptp, struct board_info,
					     ptp_caps);
	mutex_lock(&db->tsreg_lock);
	dm9051_set_reg(db, DM9051_1588_CLK_CTRL, DM9051_CCR_IDX_RST);
	dm9051_set_reg(db, DM9051_1588_TS, (uint8_t)(ts->tv_nsec & 0xff));             // Write register 0x68
	dm9051_set_reg(db, DM9051_1588_TS, (uint8_t)((ts->tv_nsec >> 8) & 0xff));      // Write register 0x68
	dm9051_set_reg(db, DM9051_1588_TS, (uint8_t)((ts->tv_nsec >> 16) & 0xff));     // Write register 0x68
	dm9051_set_reg(db, DM9051_1588_TS, (uint8_t)((ts->tv_nsec >> 24) & 0xff));     // Write register 0x68

        dm9051_set_reg(db, DM9051_1588_TS, (uint8_t)(ts->tv_sec & 0xff));             // Write register 0x68
	dm9051_set_reg(db, DM9051_1588_TS, (uint8_t)((ts->tv_sec >> 8) & 0xff));      // Write register 0x68
	dm9051_set_reg(db, DM9051_1588_TS, (uint8_t)((ts->tv_sec >> 16) & 0xff));     // Write register 0x68
	dm9051_set_reg(db, DM9051_1588_TS, (uint8_t)((ts->tv_sec >> 24) & 0xff));     // Write register 0x68

	dm9051_set_reg(db, DM9051_1588_CLK_CTRL, DM9051_CCR_PTP_WRITE);
	mutex_unlock(&db->tsreg_lock);

	dm_printk("######################### ptp_9051_settime() ts->tv_sec =  %llx, ts->tv_nsec = %lx  ###", ts->tv_sec, ts->tv_nsec);
	return 0;
}


//Stone add for 1588 GP1 trigger edge output enale !
#define DM9051_PTP_SEC_DELAY 60
#define DEBUG_PPS            1
static void dm9051_pps_configure(struct ptp_clock_info *ptp)
{
	struct timespec64 now; //, tmp;
	//u64 ns;
	unsigned int temp[9];
	int ret;
	struct board_info *db = container_of(ptp, struct board_info,
					     ptp_caps);

	//Read dm9051 ptp clock now!
	//ptp_9051_gettime(ptp, &tmp);
	ptp_9051_gettime(ptp, &now);
	//Stone add for sec & nsec bug!!!!
	//printk("dm9051_pps_configure gettime tmp.tv_sec = 0x%llx, tmp.tv_nsec = 0x%lx \r\n", tmp.tv_sec, tmp.tv_nsec);
	//now.tv_nsec = tmp.tv_sec;
	//now.tv_sec = tmp.tv_nsec;
	printk("111 dm9051_pps_configure trigger time now.tv_sec = 0x%llx, now.tv_nsec = 0x%lx 111\r\n", now.tv_sec, now.tv_nsec);
	//printk("111 temp[4-7] %x %x %x %x \r\n", now.tv_sec & 0xff, (now.tv_sec>>8) & 0xff, (now.tv_sec>>16) & 0xff, (now.tv_sec>>24) & 0xff);
	//now.tv_sec = now.tv_sec + DM9051_PTP_SEC_DELAY;   //Stone add for 2024-05-14 GP1 trigger time setup to 0xabcdff sec, 0x00 nsec
	now.tv_nsec = 0;

	temp[0]= 0x00;
	temp[1]= 0x00;
	temp[2]= 0x00;
	temp[3]= 0x00;
	temp[4]= 0xff;
	temp[5]= (now.tv_sec>>8) & 0xff;
	temp[6]= (now.tv_sec>>16) & 0xff;
	temp[7]= (now.tv_sec>>24) & 0xff;

#undef GP1_TEST
#ifdef GP1_TEST //===================================
	//Setup GP1 to edge trigger output!
	//Register 0x60 to 0x0 (GP page (bit 1), PTP Function(bit 0))
	dm9051_set_reg(db, DM9051_1588_ST_GPIO, 0x00);

#if DEBUG_PPS
	dm9051_get_reg(db, DM9051_1588_ST_GPIO, &temp[8]);
	printk("Register 0x60 (0x00) = 0x%x \r\n", temp[8]);
#endif

	//Register 0x6A to 0x06 (interrupt disable(bit 2), trigger or event enable(bit 1), trigger output(bit 0))
	dm9051_set_reg(db, DM9051_1588_GPIO_CONF, 0x06);

#if DEBUG_PPS
	dm9051_get_reg(db, DM9051_1588_GPIO_CONF, &temp[8]);
	printk("Register 0x6A (0x06) = 0x%x \r\n", temp[8]);
#endif

	//Register 0x6B to 0x02(trigger out type: edge output(bit 3:2),  triger output active high(bit 1))
	dm9051_set_reg(db, DM9051_1588_GPIO_TE_CONF, 0x02);

#if DEBUG_PPS
	dm9051_get_reg(db, DM9051_1588_GPIO_TE_CONF, &temp[8]);
	printk("Register 0x6B (0x02) = 0x%x \r\n", temp[8]);
#endif
#endif // DEBUT_PPS
	mutex_lock(&db->tsreg_lock);
	//Register 0x61 to 0x80
	dm9051_set_reg(db, DM9051_1588_CLK_CTRL, 0x80);

#if DEBUG_PPS
	ret = dm9051_get_reg(db, DM9051_1588_CLK_CTRL, &temp[8]);
	printk("Register 0x61 (0x80) = 0x%x \r\n", temp[8]);
#endif


	//Register 0x68 to now.tv_nsec & now.tv_sec !
	for (int i=0; i<8 ;i++)
		dm9051_set_reg(db, DM9051_1588_TS, temp[i]);
	mutex_unlock(&db->tsreg_lock);


	//Register 0x62 to 0x10 (GP 1 trigger load or event Read)
	dm9051_set_reg(db, DM9051_1588_GP_TXRX_CTRL, 0x10);

#if DEBUG_PPS
	dm9051_get_reg(db, DM9051_1588_GP_TXRX_CTRL, &temp[8]);
	printk("Register 0x62 (0x10) = 0x%x \r\n", temp[8]);
#endif

#if DEBUG_PPS
	dm9051_get_reg(db, DM9051_1588_ST_GPIO, &temp[8]);
	printk("Register 0x60 (0x00) = 0x%x \r\n", temp[8]);
#endif

#if DEBUG_PPS
	dm9051_get_reg(db, DM9051_1588_GPIO_CONF, &temp[8]);
	printk("Register 0x6A (0x06) = 0x%x \r\n", temp[8]);
#endif

#if DEBUG_PPS
	dm9051_get_reg(db, DM9051_1588_GPIO_TE_CONF, &temp[8]);
	//temp[8] = ior(db, DM9051_1588_GPIO_TE_CONF);
	printk("Register 0x6B (0x02) = 0x%x \r\n", temp[8]);

	printk("temp[0-7] = %x %x %x %x %x %x %x %x \r\n", temp[0], temp[1], temp[2], temp[3], temp[4], temp[5], temp[6], temp[7]);
#endif


	printk("@@@ dm9051_pps_configure trigger time now.tv_sec = 0x%llx, now.tv_nsec = 0x%lx @@@\r\n", now.tv_sec, now.tv_nsec);
}


static void dm9051_perout(struct ptp_clock_info *ptp, struct ptp_clock_request *rq)
{
	//struct timespec64 now;
	//int i;
	unsigned int temp_1[8],temp;

	struct board_info *db = container_of(ptp, struct board_info,
					     ptp_caps);
	dm9051_get_reg(db, DM9051_1588_ST_GPIO, &temp);

	printk("Read Register 0x60 = 0x%x \r\n", temp);

	if ((temp & 0x80) == 0x80) //GP2 trigger/event status ready
	{
		if ((temp & 0x40) == 0x40) //GP2 event is rising edge!
		{
			//Stone add for 1588 read GP2 "event timestamp" !
			//Register 0x62 to 0x20 (GP1 trigger load or event read (bit 5), GP page (bit 1), PTP Function(bit 0))
			printk("GP 2 have event intput!!!, read event timestamp!\r\n");
			//dm9051_set_reg(db, DM9051_1588_GP_TXRX_CTRL, 0x20);
			dm9051_get_reg(db, DM9051_1588_GP_TXRX_CTRL, &temp);
			printk("Read Register 0x62 (0x0) = 0x%x \r\n", temp);

			//ptp_9051_gettime(ptp, &now);
			dm9051_set_reg(db, DM9051_1588_CLK_CTRL, 0x80);
			//for (i=0; i<8; i++)
			//	temp_1[i] = ior(db, DM9051_1588_TS);
			dm9051_read_mem(db, DM9051_1588_TS, temp_1, DM9051_1588_TS_BULK_SIZE);

			rq->perout.start.nsec = (((temp_1[2] | (temp_1[3] << 8)) << 16) | (temp_1[0] | (temp_1[1] << 8)));//val[0] | (val[1] << 16);
			rq->perout.start.sec  = (((temp_1[6] | (temp_1[7] << 8)) << 16) | (temp_1[4] | (temp_1[5] << 8)));//val[2] | (val[3] << 16);

			printk("dm9051_perout => rq->perout.start.sec = 0x%llx, rq->perout.start.nsec = 0x%x\r\n", rq->perout.start.sec, rq->perout.start.nsec);
		}else printk("GP2 event is NOT rising edge!!!!!\r\n");

	}else printk("GP2 trigger/event status NOT ready!!!!\r\n");

}

//Stone add for enable GP2 event input mode!!!
static void dm9051_extts(struct ptp_clock_info *ptp)
{
	struct board_info *db = container_of(ptp, struct board_info,
					     ptp_caps);
	unsigned int gpio_val;
	u8 cur_ts[8];
	struct ptp_clock_time g2_event;
	int i;

	//gpio_val = ior(db, DM9051_1588_ST_GPIO);
	dm9051_get_reg(db, DM9051_1588_ST_GPIO, &gpio_val);
	printk("Read Register 0x60 = 0x%x \r\n", gpio_val);

	if ((gpio_val & 0x80) == 0x80) //GP2 trigger/event status ready
	{
		if ((gpio_val & 0x40) == 0x40) //GP2 event is rising edge!
		{
			//Stone add for 1588 read GP2 "event timestamp" !
			//Register 0x62 to 0x20 (GP1 trigger load or event read (bit 5), GP page (bit 1), PTP Function(bit 0))
			printk("GP 2 have event intput!!!, read event timestamp!\r\n");
			dm9051_set_reg(db, DM9051_1588_GP_TXRX_CTRL, 0x20);

			//gpio_val = ior(db, DM9051_1588_GP_TXRX_CTRL);
			dm9051_get_reg(db, DM9051_1588_GP_TXRX_CTRL, &gpio_val);
			printk("Read Register 0x62 (0x0) = 0x%x \r\n", gpio_val);

			//ptp_9051_gettime(ptp, &now);
			mutex_lock(&db->tsreg_lock);
			dm9051_set_reg(db, DM9051_1588_CLK_CTRL, DM9051_CCR_IDX_RST);
			for (i=0; i<8; i++)
				dm9051_get_reg8(db, DM9051_1588_TS, &cur_ts[i]);
			mutex_unlock(&db->tsreg_lock);
			g2_event.nsec = (((cur_ts[2] | (cur_ts[3] << 8)) << 16) | (cur_ts[0] | (cur_ts[1] << 8)));
			g2_event.sec  = (((cur_ts[6] | (cur_ts[7] << 8)) << 16) | (cur_ts[4] | (cur_ts[5] << 8)));

			printk("dm9051_perout => g2_event.sec = 0x%llx, g2_event.nsec = 0x%x\r\n", g2_event.sec, g2_event.nsec);
		}
	}else{

		//Setup GP2 to event input!
		//Register 0x60 to 0x2 (GP page (bit 1), PTP Function(bit 0))
		dm9051_set_reg(db, DM9051_1588_ST_GPIO, 0x02);

#if DEBUG_PPS
		//gpio_val = ior(db, DM9051_1588_ST_GPIO);
		dm9051_get_reg(db,DM9051_1588_ST_GPIO, &gpio_val);
		printk("Register 0x60 (0x02) = 0x%x \r\n", gpio_val);
#endif

		//Register 0x6A to 0x07 (interrupt disable(bit 2), trigger or event enable(bit 1), trigger output(bit 0))
		dm9051_set_reg(db, DM9051_1588_GPIO_CONF, 0x07);

#if DEBUG_PPS
		//gpio_val = ior(db, DM9051_1588_GPIO_CONF);
		dm9051_get_reg(db, DM9051_1588_GPIO_CONF, &gpio_val);
		printk("Register 0x6A (0x07) = 0x%x \r\n", gpio_val);
#endif

		//Register 0x6B to 0x60(trigger out type: edge output(bit 3:2),  triger output active high(bit 1))
		dm9051_set_reg(db, DM9051_1588_GPIO_TE_CONF, 0x60);

#if DEBUG_PPS
		//gpio_val = ior(db, DM9051_1588_GPIO_TE_CONF);
		dm9051_get_reg(db, DM9051_1588_GPIO_TE_CONF, &gpio_val);
		printk("Register 0x6B (0x60) = 0x%x \r\n", gpio_val);
#endif

		//Register 0x61 to 0x80
		//dm9051_set_reg(db, DM9051_1588_CLK_CTRL, 0x80);

#if DEBUG_PPS
		//gpio_val = ior(db, DM9051_1588_ST_GPIO);
		dm9051_get_reg(db, DM9051_1588_ST_GPIO, &gpio_val);
		printk("Check Register 0x60  = 0x%x \r\n", gpio_val);
#endif
	}

}

static int ptp_9051_feature_enable(struct ptp_clock_info *ptp,
				   struct ptp_clock_request *rq, int on)
{
	//struct board_info *db = container_of(ptp, struct board_info,
	//					       ptp_caps);
	printk("!!! 1. ptp_9051_feature_enable in rq->type = 0x%x,  on = 0x%x\n", rq->type, on);

	switch (rq->type) {
		case PTP_CLK_REQ_EXTTS:
			printk("2. ptp_9051_feature_enable PTP_CLK_REQ_EXTTS \n");
			printk("   rq->extts.index = 0x%x, rq->extts.flags = 0x%x, rq->extts.rsv[0] = 0x%x, rq->extts.rsv[1] = 0x%x \r\n", rq->extts.index, rq->extts.flags, rq->extts.rsv[0], rq->extts.rsv[1]);
			//func = PTP_PF_EXTTS;
			//chan = rq->extts.index;
			dm9051_extts(ptp); //Stone add for enable GP2 event input!
			break;
		case PTP_CLK_REQ_PEROUT:
			printk("3. ptp_9051_feature_enable PTP_CLK_REQ_PEROUT \n");
			printk("   rq->perout.index = 0x%x, rq->perout.start.sec = 0x%llx, rq->perout.start.nsec = 0x%x, rq->perout.period.sec = 0x%llx, rq->perout.period.nsec = 0x%x\r\n", rq->perout.index, rq->perout.start.sec, rq->perout.start.nsec, rq->perout.period.sec, rq->perout.period.nsec);
			//func = PTP_PF_PEROUT;
			//chan = rq->perout.index;
			dm9051_perout(ptp, rq); //Stone add for read GP2 status, and read PTP clock data to ptp4l!
			break;
		case PTP_CLK_REQ_PPS:
			printk("4. ptp_9051_feature_enable PTP_CLK_REQ_PPS \n");
			//return i40e_pps_configure(ptp, rq, on);
			//Stone add for 1588 pps enable "echo 1 > /sys/class/ptp/ptp0/pps_enable"
			if (on){
				dm9051_pps_configure(ptp);
			}
			break;
		default:
			return 0;
	}

	//Stone add for 1588 pps
	return 0;

}

static void dm9051_GP1_setup(struct board_info *db)
{
	unsigned int TX_tmp[9];
	struct timespec64 now;
	int temp;
	//int  i;

        //temp = ior(db, DM9051_1588_ST_GPIO);
	dm9051_get_reg(db, DM9051_1588_ST_GPIO, &temp);
	printk("Read Register 0x60 = 0x%x \r\n", temp);

	if ((temp & 0x20) == 0x20) //GP1 trigger/event status ready
	{
		//if ((temp & 0x10) == 0x10) //GP1 event is rising edge!
		{
			dm9051_set_reg(db, DM9051_1588_ST_GPIO, 0x20); //Clear GP1 stauts!

			ptp_9051_gettime(&db->ptp_caps, &now);

			TX_tmp[4]= now.tv_sec & 0xff;
			//TX_tmp[5]= (now.tv_sec>>8) & 0xff;
			//TX_tmp[6]= (now.tv_sec>>16) & 0xff;
			//TX_tmp[7]= (now.tv_sec>>24) & 0xff;

//Stone add for GP1 trigger output!
			//==============================================
			if ((TX_tmp[4] & 0xf) == 0xf)
			{
				//if (trigger_70){
				TX_tmp[0] = 0x00;
				TX_tmp[1] = 0x00;
				TX_tmp[2] = 0x00;
				TX_tmp[3] = 0x00;

				now.tv_sec = now.tv_sec +0x10;

				TX_tmp[4]= now.tv_sec & 0xff;
				TX_tmp[5]= (now.tv_sec>>8) & 0xff;
				TX_tmp[6]= (now.tv_sec>>16) & 0xff;
				TX_tmp[7]= (now.tv_sec>>24) & 0xff;

				//Setup GP1 trigger time!
				//Register 0x61 to 0x80
				dm9051_set_reg(db, DM9051_1588_CLK_CTRL, 0x80);

//#if DEBUG_PPS
#if 1
				//temp = ior(db, DM9051_1588_CLK_CTRL);
				dm9051_get_reg(db, DM9051_1588_CLK_CTRL, &temp);
				printk("Register 0x61 (0x80) = 0x%x \r\n", temp);
#endif

				mutex_lock(&db->spi_lockm);
				//Register 0x68 to now.tv_nsec & now.tv_sec !
				for (int i=0; i<8 ;i++)
					dm9051_set_reg(db, DM9051_1588_TS, TX_tmp[i]);
				mutex_unlock(&db->spi_lockm);

				//Register 0x62 to 0x10 (GP 1 trigger load or event Read)
				dm9051_set_reg(db, DM9051_1588_GP_TXRX_CTRL, 0x10);

				//trigger_70 = 0x00;
				//trigger_ff = 0x01;
				printk(" Trigger time = %02x-%02x-%02x-%02x-%02x-%02x-%02x-%02x\n",
				       TX_tmp[0], TX_tmp[1],TX_tmp[2],TX_tmp[3],TX_tmp[4],TX_tmp[5],TX_tmp[6],TX_tmp[7]);
				//}
			}else { //TX_tmp[4] & 0xf != 0xf
				//if (trigger_70){
				TX_tmp[0] = 0x00;
				TX_tmp[1] = 0x00;
				TX_tmp[2] = 0x00;
				TX_tmp[3] = 0x00;

				//now.tv_sec = now.tv_sec +0x10;

				TX_tmp[4]= (now.tv_sec & 0xff) | 0x0f;
				TX_tmp[5]= (now.tv_sec>>8) & 0xff;
				TX_tmp[6]= (now.tv_sec>>16) & 0xff;
				TX_tmp[7]= (now.tv_sec>>24) & 0xff;

				//Setup GP1 trigger time!
				//Register 0x61 to 0x80
				dm9051_set_reg(db, DM9051_1588_CLK_CTRL, 0x80);

//#if DEBUG_PPS
#if 1
				//temp = ior(db, DM9051_1588_CLK_CTRL);
				dm9051_get_reg(db, DM9051_1588_CLK_CTRL, &temp);
				printk("Register 0x61 (0x80) = 0x%x \r\n", temp);
#endif

				mutex_lock(&db->spi_lockm);
				//Register 0x68 to now.tv_nsec & now.tv_sec !
				for (int i=0; i<8 ;i++)
					dm9051_set_reg(db, DM9051_1588_TS, TX_tmp[i]);
				mutex_unlock(&db->spi_lockm);

				//Register 0x62 to 0x10 (GP 1 trigger load or event Read)
				dm9051_set_reg(db, DM9051_1588_GP_TXRX_CTRL, 0x10);

				//trigger_70 = 0x00;
				//trigger_ff = 0x01;
				printk(" Trigger time = %02x-%02x-%02x-%02x-%02x-%02x-%02x-%02x\n",
				       TX_tmp[0], TX_tmp[1],TX_tmp[2],TX_tmp[3],TX_tmp[4],TX_tmp[5],TX_tmp[6],TX_tmp[7]);
				//}
			} //end of "TX_tmp[4] & 0xf != 0xf"
		}
	}else{

		if (trigger_70){
			ptp_9051_gettime(&db->ptp_caps, &now);

			TX_tmp[4]= now.tv_sec & 0xff;

//Stone add for GP1 trigger output!
			//==============================================
			if ((TX_tmp[4] & 0xf) == 0xf)
			{
				TX_tmp[0] = 0x00;
				TX_tmp[1] = 0x00;
				TX_tmp[2] = 0x00;
				TX_tmp[3] = 0x00;

				now.tv_sec = now.tv_sec +0x10;

				TX_tmp[4]= now.tv_sec & 0xff;
				TX_tmp[5]= (now.tv_sec>>8) & 0xff;
				TX_tmp[6]= (now.tv_sec>>16) & 0xff;
				TX_tmp[7]= (now.tv_sec>>24) & 0xff;

				//Setup GP1 trigger time!
				//Register 0x61 to 0x80
				dm9051_set_reg(db, DM9051_1588_CLK_CTRL, 0x80);

//#if DEBUG_PPS
#if 1
				//temp = ior(db, DM9051_1588_CLK_CTRL);
				dm9051_get_reg(db, DM9051_1588_CLK_CTRL, &temp);
				printk("Register 0x61 (0x80) = 0x%x \r\n", temp);
#endif

				mutex_lock(&db->spi_lockm);
				//Register 0x68 to now.tv_nsec & now.tv_sec !
				for (int i=0; i<8 ;i++)
					dm9051_set_reg(db, DM9051_1588_TS, TX_tmp[i]);
				mutex_unlock(&db->spi_lockm);

				//Register 0x62 to 0x10 (GP 1 trigger load or event Read)
				dm9051_set_reg(db, DM9051_1588_GP_TXRX_CTRL, 0x10);

				trigger_70 = 0x00;
				//trigger_ff = 0x01;
				printk(" Trigger time = %02x-%02x-%02x-%02x-%02x-%02x-%02x-%02x\n",
				       TX_tmp[0], TX_tmp[1],TX_tmp[2],TX_tmp[3],TX_tmp[4],TX_tmp[5],TX_tmp[6],TX_tmp[7]);

			}
		}
	}
}



#if 1
static void dm9051_ptp_extts0_work(struct work_struct *work)
{
	//struct i40e_pf *pf = container_of(work, struct i40e_pf,
	//				  ptp_extts0_work);
        struct board_info *db = container_of(work, struct board_info,
					     ptp_extts0_work);
	//struct i40e_hw *hw = &pf->hw;
	//struct ptp_clock_event event;
	//u32 hi, lo;

	printk("dm9051_ptp_extts0_work in\r\n");
	/* Event time is captured by one of the two matched registers
	 *      PRTTSYN_EVNT_L: 32 LSB of sampled time event
	 *      PRTTSYN_EVNT_H: 32 MSB of sampled time event
	 * Event is defined in PRTTSYN_EVNT_0 register
	 */

	//lo = rd32(hw, I40E_PRTTSYN_EVNT_L(0));
	//hi = rd32(hw, I40E_PRTTSYN_EVNT_H(0));

	//dm9051_pps_configure(&db->ptp_caps);
	dm9051_GP1_setup(db);
}
#endif


static int ptp_9051_verify_pin(struct ptp_clock_info *ptp, unsigned int pin,
			       enum ptp_pin_function func, unsigned int chan)
{
	//struct board_info *db = container_of(ptp, struct board_info,
	//			   	         ptp_caps);

	printk("!!! 1. ptp_9051_verify_pin in\n");

	return 0;
}

/**
 * dm9051_ptp_get_ts_config - get hardware time stamping config
 * @netdev:
 * @ifreq:
 *
 * Get the hwtstamp_config settings to return to the user. Rather than attempt
 * to deconstruct the settings from the registers, just return a shadow copy
 * of the last known settings.
 **/

int dm9051_ptp_get_ts_config(struct net_device *netdev, struct ifreq *ifr)
{
	struct board_info *db = netdev_priv(netdev);
	struct hwtstamp_config *config = &db->tstamp_config;
        dm_printk("[in %s()]", __FUNCTION__);
	return copy_to_user(ifr->ifr_data, config, sizeof(*config)) ?
		-EFAULT : 0;

}

/**
 *  dm9051_ptp_set_timestamp_mode - setup hardware for timestamping
 *  @adapter: our device structure
 *  @config: hwtstamp configuration
 *
 *  Outgoing time stamping can be enabled and disabled. Play nice and
 *  disable it when requested, although it shouldn't case any overhead
 *  when no packet needs it. At most one packet in the queue may be
 *  marked for time stamping, otherwise it would be impossible to tell
 *  for sure to which packet the hardware time stamp belongs.
 *
 *  Incoming time stamping has to be configured via the hardware
 *  filters. Not all combinations are supported, in particular event
 *  type has to be specified. Matching the kind of event packet is
 *  not supported, with the exception of "all V2 events regardless of
 *  level 2 or 4".
 */

static int dm9051_ptp_set_timestamp_mode(struct board_info *db,
					 struct hwtstamp_config *config)
{
	u32 rx_ctl = 0;
	u32 tx_ctl = 0;
	u32 rx_cfg = 0;
	bool is_l4 = false;
	bool is_l2 = false;
	int ret = 0;


	/* reserved for future extensions */
	//if (config->flags)
	//	return -EINVAL;

	if (config->tx_type < __HWTSTAMP_TX_CNT) {
		tx_ctl = (1 << config->tx_type);
	} else {
		ret = -ERANGE;
		goto end_func;
	}

	switch (config->rx_filter) {
		case HWTSTAMP_FILTER_NONE:
			rx_ctl = 0;
			break;
		case HWTSTAMP_FILTER_PTP_V1_L4_SYNC:
			rx_ctl |= DM9051_RXCTL_TYPE_L4_V1;
			rx_cfg = DM9051_RXCFG_PTP_V1_SYNC_MESSAGE;
			is_l4 = true;
			break;
		case HWTSTAMP_FILTER_PTP_V1_L4_DELAY_REQ:
			rx_ctl |= DM9051_RXCTL_TYPE_L4_V1;
			rx_cfg = DM9051_RXCFG_PTP_V1_DELAY_REQ_MESSAGE;
			is_l4 = true;
			break;
		case HWTSTAMP_FILTER_PTP_V2_EVENT:
		case HWTSTAMP_FILTER_PTP_V2_L2_EVENT:
		case HWTSTAMP_FILTER_PTP_V2_L4_EVENT:
		case HWTSTAMP_FILTER_PTP_V2_SYNC:
		case HWTSTAMP_FILTER_PTP_V2_L2_SYNC:
		case HWTSTAMP_FILTER_PTP_V2_L4_SYNC:
		case HWTSTAMP_FILTER_PTP_V2_DELAY_REQ:
		case HWTSTAMP_FILTER_PTP_V2_L2_DELAY_REQ:
		case HWTSTAMP_FILTER_PTP_V2_L4_DELAY_REQ:
			rx_ctl |= DM9051_RXCTL_TYPE_EVENT_V2;
			config->rx_filter = HWTSTAMP_FILTER_PTP_V2_EVENT;
			is_l2 = true;
			is_l4 = true;
			break;
		case HWTSTAMP_FILTER_PTP_V1_L4_EVENT:
		case HWTSTAMP_FILTER_ALL:
			/*
			 * timestamp all packets, which it needs to do to
			 * support both V1 Sync and Delay_Req messages
			 */
			rx_ctl |= DM9051_RXCTL_TYPE_ALL;
			config->rx_filter = HWTSTAMP_FILTER_ALL;
			break;
		default:
			config->rx_filter = HWTSTAMP_FILTER_NONE;
			ret = -ERANGE;
			goto end_func;
	}

	/*
	 * Per-packet timestamping only works if all packets are
	 * timestamped, so enable timestamping in all packets as
	 * long as one rx filter was configured.
	 */
	config->rx_filter = HWTSTAMP_FILTER_ALL;
	is_l2 = true;
	is_l4 = true;
end_func:
	db->rx_ctl = rx_ctl;
	db->tx_ctl = tx_ctl;
	db->rx_cfg = rx_cfg;
	db->is_l2 = is_l2;
	db->is_l4 = is_l4;
        dm_printk("[in %s()] config fields: tx_type = %X, rx_filter = %X, flags = %X, return = %d",
		  __FUNCTION__, config->tx_type, config->rx_filter, config->flags, ret);
	return ret;
}

/**
 * dm9051_ptp_set_ts_config - set hardware time stamping config
 * @netdev:
 * @ifreq:
 *
 **/
int dm9051_ptp_set_ts_config(struct net_device *netdev, struct ifreq *ifr)
{
	struct board_info *db = netdev_priv(netdev);
	struct hwtstamp_config config;
	int err;

	if (copy_from_user(&config, ifr->ifr_data, sizeof(config)))
		return -EFAULT;

	err = dm9051_ptp_set_timestamp_mode(db, &config);
	if (err) {
		dm_printk("[in %s()] return err = %d", __FUNCTION__, err);
		return err;
	}

	/* save these settings for future reference */
	memcpy(&db->tstamp_config, &config,
	       sizeof(db->tstamp_config));

	return copy_to_user(ifr->ifr_data, &config, sizeof(config)) ?
		-EFAULT : 0;
}

inline int dm9051_get_reg8(struct board_info *db, u8 reg, u8 *val)
{
	unsigned int intval;
	int ret = dm9051_get_reg(db, reg, &intval);
	*val = intval & 0xff;
	return ret;
}

void dm9051_ptp_tx_hwtstamp(struct board_info *db, struct sk_buff *skb)
{
	struct skb_shared_hwtstamps shhwtstamps;
	u8 temp[8];
	u64 ns;
	memset(temp, 0, sizeof(temp));
	// tsreg_lock protect
	mutex_lock(&db->tsreg_lock);
	// reset ptp clock index
	dm9051_set_reg(db, DM9051_1588_CLK_CTRL, DM9051_CCR_IDX_RST);
	// read TX Time Stamp Clock Register 0x62, value 0x01
	dm9051_set_reg(db, DM9051_1588_GP_TXRX_CTRL, DM9051_GPTXRX_RD_TS);
	// read 8 bytes timestamp
	for (int i = 0; i < DM9051_1588_TS_BULK_SIZE; i++)
		dm9051_get_reg8(db, DM9051_1588_TS, &temp[i]);

	mutex_unlock(&db->tsreg_lock);
#ifdef DE_TIMESTAMP
	dm_printk(" TXTXTXTXTX hwtstamp 0x68 = %02x-%02x-%02x-%02x-%02x-%02x-%02x-%02x \r\n",
	       temp[0], temp[1],temp[2],temp[3],temp[4],temp[5],temp[6],temp[7]);
#endif
	// p[1] is sec, p[0] is ns
	u32* p = (u32*)temp;

#ifdef DE_TIMESTAMP
	dm_printk(" TXTXTXTX hwtstamp sec = 0x%x, ns = 0x%x \r\n", p[1], p[0]);
#endif
	ns = p[1] * 1000000000ULL + p[0];
	memset(&shhwtstamps, 0, sizeof(shhwtstamps));
	shhwtstamps.hwtstamp = ns_to_ktime(ns);
	skb_tstamp_tx(skb, &shhwtstamps);
}


//
// dm9051_ptp_rx_hwtstamp():
//     parse 8 bytes RX timestamp read from chip packet header, then put in skb
//
void dm9051_ptp_rx_hwtstamp(struct board_info *db, struct sk_buff *skb, u8 *rxTSbyte)
{
	struct skb_shared_hwtstamps *shhwtstamps = NULL;

	// timestamp read from dm9051a memory is big-endian
	// x86-pc & raspberry pi is little-endian
	u32 sec = be32_to_cpu(*(u32*)rxTSbyte);
	u64 ns = be32_to_cpu(*(u32*)(rxTSbyte + 4));

	ns += sec * 1000000000ULL;
	shhwtstamps = skb_hwtstamps(skb);
	memset(shhwtstamps, 0, sizeof(*shhwtstamps));
	shhwtstamps->hwtstamp = ns_to_ktime(ns);

	dm9051_set_reg(db, DM9051_1588_ST_GPIO, 0x08); //Clear RX Time Stamp Clock Register offset 0x60, value 0x08

}


static void ptp_9051_tx_work(struct work_struct *work)
{
	struct board_info *db = container_of(work, struct board_info,
					     ptp_tx_work);
	int tsynctxctl;
	printk("==> ptp_9051_tx_work in \r\n");
	if (!db->ptp_tx_skb)
		return;

#if 0  //Stone add
	if (time_is_before_jiffies(db->ptp_tx_start +
				   IGB_PTP_TX_TIMEOUT)) {
		dev_kfree_skb_any(db->ptp_tx_skb);
		db->ptp_tx_skb = NULL;
		clear_bit_unlock(__IGB_PTP_TX_IN_PROGRESS, &db->state);
		db->tx_hwtstamp_timeouts++;
		dev_warn(&db->pdev->dev, "clearing Tx timestamp hang\n");
		return;
	}
#endif

	//tsynctxctl = ior(db, DM9051_1588_ST_GPIO);        //Read register 0x60 bit 2
	dm9051_get_reg(db, DM9051_1588_ST_GPIO, &tsynctxctl);
        //printk("ptp_9051_tx_work register 0x60 = %x \r\n", tsynctxctl);
#if 0
	if (tsynctxctl & 0x04)   //
		dm9051_ptp_tx_hwtstamp(db);
	else
		/* reschedule to check later */
		schedule_work(&db->ptp_tx_work);
#endif
	printk("<== ptp_9051_tx_work out \r\n");
}

const char dm9051_ptp__driver_name[] = "DM9051 PTP";

void dm9051_ptp_init(struct board_info *db)
{
	uint temp;

        strncpy(db->ptp_caps.name, dm9051_ptp__driver_name, sizeof(db->ptp_caps.name));
	db->ptp_caps.owner = THIS_MODULE;
	db->ptp_caps.max_adj = 50000000;
	db->ptp_caps.n_ext_ts = N_EXT_TS;
        db->ptp_caps.n_per_out = N_PER_OUT;
	db->ptp_caps.pps = 1;  //Stone add for 1588 pps

	db->ptp_caps.adjfine = ptp_9051_adjfine;
	db->ptp_caps.adjtime = ptp_9051_adjtime;
	db->ptp_caps.gettime64 = ptp_9051_gettime;
	db->ptp_caps.settime64 = ptp_9051_settime;
	db->ptp_caps.enable = ptp_9051_feature_enable;
	db->ptp_caps.verify = ptp_9051_verify_pin;
	db->last_rate = 0;


	INIT_WORK(&db->ptp_tx_work, ptp_9051_tx_work);

        db->tstamp_config.flags = 0;
	db->tstamp_config.rx_filter =
		(1 << HWTSTAMP_FILTER_ALL) |
		(1 << HWTSTAMP_FILTER_SOME) |
		(1 << HWTSTAMP_FILTER_NONE);
	db->tstamp_config.tx_type =
		(1 << HWTSTAMP_TX_ONESTEP_SYNC) |
		(1 << HWTSTAMP_TX_ON) |
		(1 << HWTSTAMP_TX_OFF);


        printk("ptp_clock_register in \r\n");
	db->ptp_clock = ptp_clock_register(&db->ptp_caps,
					   &db->ndev->dev);
        printk("ptp_clock_register end \r\n");
	if (IS_ERR(db->ptp_clock)) {
		db->ptp_clock = NULL;
		dev_err(&db->spidev->dev, "ptp_clock_register failed\n");
	}  else if (db->ptp_clock) {
		printk("added PHC on %s\n",
		       db->ndev->name);
	}
        db->ptp_flags |= IGB_PTP_ENABLED;

	INIT_WORK(&db->ptp_extts0_work, dm9051_ptp_extts0_work);

	// Enable h/w capture rx timestamp
	dm9051_set_reg(db, DM9051_1588_RX_CONF1,
		       DM9051A_RC_SLAVE | DM9051A_RC_RXTS_EN | DM9051A_RC_RX2_EN);
        // Enable PTP h/w functions
	dm9051_set_reg(db, DM9051_1588_CLK_CTRL, DM9051_CCR_PTP_EN);

	dm9051_set_reg(db, DM9051_1588_ST_GPIO, 0x00);

#if 1 //===================================
	//Setup GP1 to edge trigger output!
	//Register 0x60 to 0x0 (GP page (bit 1), PTP Function(bit 0))
	dm9051_set_reg(db, DM9051_1588_ST_GPIO, 0x00);

#if DEBUG_PPS
	//temp = ior(db, DM9051_1588_ST_GPIO);
	dm9051_get_reg(db, DM9051_1588_ST_GPIO, &temp);
	printk("Register 0x60 (0x00) = 0x%x \r\n", temp);
#endif

	//Register 0x6A to 0x06 (interrupt disable(bit 2), trigger or event enable(bit 1), trigger output(bit 0))
	dm9051_set_reg(db, DM9051_1588_GPIO_CONF, 0x06);

#if DEBUG_PPS
	//temp = ior(db, DM9051_1588_GPIO_CONF);
	dm9051_get_reg(db, DM9051_1588_GPIO_CONF, &temp);
	printk("Register 0x6A (0x06) = 0x%x \r\n", temp);
#endif

	//Register 0x6B to 0x02(trigger out type: edge output(bit 3:2),  triger output active high(bit 1))
	dm9051_set_reg(db, DM9051_1588_GPIO_TE_CONF, 0x02);

#if DEBUG_PPS
	//temp = ior(db, DM9051_1588_GPIO_TE_CONF);
	dm9051_get_reg(db, DM9051_1588_GPIO_TE_CONF, &temp);
	printk("Register 0x6B (0x02) = 0x%x \r\n", temp);
#endif
#endif //===================================

#ifdef DM9051A
	if (check_TT9052){
		//Stone add for 1588 Read 0x68 in one SPI cycle disable (register 0x63 bit 6 0:enable, 1:disable => 0x40)
		//Stone add for 1588 TX 1-Step checksum disable (register 0x63 bit 7 0:enable, 1:disable => 0x80)
		dm9051_set_reg(db, DM9051_1588_1_STEP_CHK, 0x40 | 0x80);
	}else {//Stone add for one-step Sync packet insert time stamp! 2024-08-14!
		//Stone add for 1588 Read 0x68 in one SPI cycle enable (register 0x63 bit 6 0:enable, 1:disable => 0x40)
		//Stone add for 1588 TX 1-Step checksum enable (register 0x63 bit 7 0:enable, 1:disable => 0x80)
		dm9051_set_reg(db, DM9051_1588_1_STEP_CHK, 0x00);
	}

#endif

	// DA1082S_E1_design_report_part1.pdf datasheet.
	// 實際測試 dm9051a_ptp_pps_set GP2 enable, mac reg[0x3C] = 0xA0, bit 7~4 = 0xA, bit 3~0 = 0x0
	// Set MAC REG_3CH = 0xa0
	// GP1: 80ns pulse per 1 sec
	// GP2: toggle per 1 sec
	// cspi_write_reg(0x3C, 0xA0);

	// Set MAC REG_3CH = 0xb0
	// LNKLED: 80ns pulse per 1 sec
	// SPDLED: toggle per 1 sec
	dm9051_set_reg(db, 0x3C, 0xB0);
}

void dm9051_ptp_stop(struct board_info *db)
{

	if (db->ptp_clock) {
		ptp_clock_unregister(db->ptp_clock);
		db->ptp_clock = NULL;
		printk("dm9051_ptp_stop remove PTP clock!!!\r\n");
	}
}


EXPORT_SYMBOL(dm9051_ptp_init);
EXPORT_SYMBOL(dm9051_get_ts_info);
MODULE_DESCRIPTION("Davicom DM9051 1588 driver");
MODULE_LICENSE("GPL");
