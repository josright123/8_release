/* SPDX-License-Identifier: GPL-2.0-only */
/*
 * Copyright (c) 2022 Davicom Semiconductor,Inc.
 * Davicom DM9051 SPI Fast Ethernet Linux driver
 */

#ifndef _DM9051_PTP_H_
#define _DM9051_PTP_H_
#include <linux/bits.h>
#include <linux/types.h>
#include <linux/skbuff.h>
#include <linux/ethtool.h>
#include <linux/ptp_clock_kernel.h>
#include <linux/version.h>  // 確保使用 LINUX_VERSION_CODE 和 KERNEL_VERSION
struct board_info;

#undef TT9052
#define DM9051A
#undef DE_TIMESTAMP

#define check_TT9052 0 //Stone add for DM9051A one-step Sync packet insert time stamp! 2024-08-14! (1:disable (TT9052 mode), 0:enable)

#ifdef TT9052
#define DM9051_1588_ST_GPIO 0x60
#define DM9051_1588_CLK_CTRL 0x61
#define DM9051_1588_GP_TXRX_CTRL x62
#define DM9051_1588_TX_CONF 0x63
#define DM9051_1588_RX_CONF1 0x64
#define DM9051_1588_RX_CONF2 0x65
#define DM9051_1588_RX_CONF3 0x66
#define DM9051_1588_CLK_P 0x67
#define DM9051_1588_TS 0x68
#define DM9051_1588_AUTO 0x69
#define DM9051_1588_GPIO_CONF 0x6A
#define DM9051_1588_GPIO_TE_CONF x6B
#define DM9051_1588_GPIO_TA_L 0x6C
#define DM9051_1588_GPIO_TA_H 0x6D
#define DM9051_1588_GPIO_DTA_L 0x6E
#define DM9051_1588_GPIO_DTA_H 0x6F
#endif // TT9052


#define DM9051_RXCTL_TYPE_L2_V2	0x00
#define DM9051_RXCTL_TYPE_L4_V1	0x02
#define DM9051_RXCTL_TYPE_L2_L4_V2	0x04
#define DM9051_RXCTL_TYPE_ALL	0x08
#define DM9051_RXCTL_TYPE_EVENT_V2	0x0A
#define DM9051_RXCTL_SYSCFI		0x00000020 /* Sys clock frequency */

#define DM9051_RXCFG_PTP_V1_CTRLT_MASK		0x000000FF
#define DM9051_RXCFG_PTP_V1_SYNC_MESSAGE		0x00
#define DM9051_RXCFG_PTP_V1_DELAY_REQ_MESSAGE	0x01
#define DM9051_RXCFG_PTP_V1_FOLLOWUP_MESSAGE	0x02
#define DM9051_RXCFG_PTP_V1_DELAY_RESP_MESSAGE	0x03
#define DM9051_RXCFG_PTP_V1_MANAGEMENT_MESSAGE	0x04

#define DM9051_RXCFG_PTP_V2_MSGID_MASK		0x00000F00
#define DM9051_RXCFG_PTP_V2_SYNC_MESSAGE		0x0000
#define DM9051_RXCFG_PTP_V2_DELAY_REQ_MESSAGE	0x0100
#define DM9051_RXCFG_PTP_V2_PATH_DELAY_REQ_MESSAGE	0x0200
#define DM9051_RXCFG_PTP_V2_PATH_DELAY_RESP_MESSAGE	0x0300
#define DM9051_RXCFG_PTP_V2_FOLLOWUP_MESSAGE	0x0800
#define DM9051_RXCFG_PTP_V2_DELAY_RESP_MESSAGE	0x0900
#define DM9051_RXCFG_PTP_V2_PATH_DELAY_FOLLOWUP_MESSAGE 0x0A00
#define DM9051_RXCFG_PTP_V2_ANNOUNCE_MESSAGE	0x0B00
#define DM9051_RXCFG_PTP_V2_SIGNALLING_MESSAGE	0x0C00
#define DM9051_RXCFG_PTP_V2_MANAGEMENT_MESSAGE	0x0D00



#ifdef DM9051A
#define DM9051_1588_ST_GPIO 0x60
#define DM9051_1588_CLK_CTRL 0x61
#define DM9051_1588_GP_TXRX_CTRL 0x62
//#define DM9051_1588_TX_CONF 0x63
#define DM9051_1588_1_STEP_CHK 0x63
#define DM9051_1588_RX_CONF1 0x64
//#define DM9051_1588_RX_CONF2 0x65
#define DM9051_1588_1_STEP_ADDR 0x65
//#define DM9051_1588_RX_CONF3 0x66
#define DM9051_1588_1_STEP_ADDR_CHK 0x66
#define DM9051_1588_CLK_P 0x67
#define DM9051_1588_TS 0x68
//#define DM9051_1588_AUTO 0x69
#define DM9051_1588_MNTR 0x69
#define DM9051_1588_GPIO_CONF 0x6A
#define DM9051_1588_GPIO_TE_CONF 0x6B
#define DM9051_1588_GPIO_TA_L 0x6C
#define DM9051_1588_GPIO_TA_H 0x6D
#define DM9051_1588_GPIO_DTA_L 0x6E
#define DM9051_1588_GPIO_DTA_H 0x6F

// bits defines
// 61H Clock Control Reg
#define DM9051_CCR_IDX_RST BIT(7)
#define DM9051_CCR_RATE_CTL BIT(6)
#define DM9051_CCR_PTP_RATE BIT(5)
#define DM9051_CCR_PTP_ADD BIT(4)
#define DM9051_CCR_PTP_WRITE BIT(3)
#define DM9051_CCR_PTP_READ BIT(2)
#define DM9051_CCR_PTP_DIS BIT(1)
#define DM9051_CCR_PTP_EN BIT(0)

// 62H
#define DM9051_GPTXRX_INT_MASK BIT(7)
// bit 6 reserved
#define DM9051_GPTXRX_GP2_TE   BIT(5)
#define DM9051_GPTXRX_GP1_TE   BIT(4)
// bit 3:1 reserved
// read tx tstamp clock
#define DM9051_GPTXRX_RD_TS    BIT(0)

// 64H
#define DM9051A_RC_SLAVE BIT(7)
#define DM9051A_RC_RXTS_EN BIT(4)
#define DM9051A_RC_RX2_EN BIT(3)
#define DM9051A_RC_FLTR_MASK 0x3
#define DM9051A_RC_FLTR_ALL_PKTS 0
#define DM9051A_RC_FLTR_MCAST_PKTS 1
#define DM9051A_RC_FLTR_DA 2
#define DM9051A_RC_FLTR_DA_SPICIFIED 3

// 69H
#define DM9051A_MNTR_IDX_68H 0xF0
#define DM9051A_MNTR_RD_RAT BIT(0)

#endif //DM9051A

#define DM9051_1588_TS_BULK_SIZE 8

#define DM9051_RC_RXTS_EN BIT(4)
#define DM9051_RC_RXTS_FLTR_MASK GENMASK(1, 0)

void dm9051_ptp_rx_hwtstamp(struct board_info *db, struct sk_buff *skb, u8 *rxTSbyte);
void dm9051_ptp_tx_hwtstamp(struct board_info *db, struct sk_buff *skb);
void dm9051_ptp_init(struct board_info *db);
void dm9051_ptp_stop(struct board_info *db);
int dm9051_ptp_set_ts_config(struct net_device *netdev, struct ifreq *ifr);
int dm9051_ptp_get_ts_config(struct net_device *netdev, struct ifreq *ifr);



#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 7, 0)

int dm9051_get_ts_info(struct net_device *net_dev,
                       struct kernel_ethtool_ts_info *ts_info);
#else

int dm9051_get_ts_info(struct net_device *net_dev,
                       struct ethtool_ts_info *ts_info);
#endif // LINUX_VERSION_CODE >= KERNEL_VERSION(6, 7, 0)



#endif // _DM9051_PTP_H_
